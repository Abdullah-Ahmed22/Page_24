// Hover First Product 
const img1 = document.getElementById('hover1');

img1.onmouseenter = function() {
img1.src = "images/Screenshot_2025-04-24_132648-removebg-preview.png";
}

img1.onmouseleave = function() {
img1.src = "images/Screenshot_2025-04-24_131044-removebg-preview.png";
}


// Hover Second Product 
const img2 = document.getElementById('hover2');

img2.onmouseenter = function() {
img2.src = "images/Screenshot_2025-04-24_133730-removebg-preview.png";
}

img2.onmouseleave = function() {
img2.src = "images/Screenshot_2025-04-24_103407-removebg-preview.png";
}


// Hover Third Product 
const img3 = document.getElementById('hover3');

img3.onmouseenter = function() {
img3.src = "images/Screenshot_2025-04-24_152915-removebg-preview.png";
}

img3.onmouseleave = function() {
img3.src = "images/Screenshot_2025-04-24_152821-removebg-preview.png";
}


// Hover Fourth Product 
const img4 = document.getElementById('hover4');

img4.onmouseenter = function() {
img4.src = "images/Screenshot_2025-04-24_151533-removebg-preview.png";
}

img4.onmouseleave = function() {
img4.src = "images/Screenshot_2025-04-24_151500-removebg-preview.png";
}


// Hover Fifth Product 
const img5 = document.getElementById('hover5');

img5.onmouseenter = function() {
img5.src = "images/Screenshot_2025-04-24_152103-removebg-preview.png";
}

img5.onmouseleave = function() {
img5.src = "images/Screenshot_2025-04-24_152023-removebg-preview.png";
}